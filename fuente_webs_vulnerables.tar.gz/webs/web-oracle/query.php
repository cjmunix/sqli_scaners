<?php

//$id = $_GET["id"];
$id = strval($_GET["id"]);

$conn = oci_connect("SYSTEM", "pinchin1", '//192.168.1.16/XE');
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

$stid = oci_parse($conn,"SELECT * FROM system.users WHERE user_id='{$id}'");
oci_execute($stid);

print "<table border='1'>\n";
while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS)) {
    print "<tr>\n";
    foreach ($row as $column => $item) {
        print "<td>" . $column . ": " . ($item !== null ? htmlentities($item, ENT_QUOTES) : "") . "</td>\n";
    }
    print "</tr>\n";
}
print "</table>\n";


oci_close($conn);
?>

