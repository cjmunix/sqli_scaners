<?php
$host = "192.168.1.16";
$db = "testdb";
$user = "test";
$pass = "test";


// Conexión a la base de datos
$conn = pg_connect("host=$host dbname=$db user=$user password=$pass");

if (!$conn) {
    die("No se pudo conectar a la base de datos: " . pg_last_error());
}

// Recuperar ID del formulario
$id = $_GET['id'];

// Consulta SQL vulnerable a inyección SQL
$query = "SELECT * FROM users WHERE user_id = $id";

$result = pg_query($conn, $query);

if (!$result) {
    die("Error en la consulta: " . pg_last_error());
}
 while ($row = pg_fetch_assoc($result)) {
        echo "ID: " . $row['user_id'] . "<br>";
        echo "Nombre de usuario: " . $row['username'] . "<br>";
        echo "Correo electrónico: " . $row['email'] . "<br>";
        echo "Passwd: "  . $row['password'] . "<br>";
}

pg_close($conn);
?>

