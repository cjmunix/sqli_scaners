<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn_array = array (
    "UID" => "sa",
    "PWD" => "Password1234",
    "Database" => "testdb",
);

//conexion
$conn = sqlsrv_connect("192.168.1.18", $conn_array);

// Obtener el id del formulario
$id = $_GET["id"];

if ($conn){
    echo "conectado" . "<br>";
    if(($result = sqlsrv_query($conn,"SELECT * FROM users WHERE user_id = $id")) !== false){
        while( $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC) ) {
            echo "ID: " . $row['user_id'] . "<br>";
            echo "Nombre de usuario: " . $row['username'] . "<br>";
            echo "Correo electrónico: " . $row['email'] . "<br>";
            echo "Passwd: " . $row['password'] . "<br>";
        }
    } else {
        if( ($errors = sqlsrv_errors() ) != null) {
            foreach( $errors as $error ) {
                echo "SQLSTATE: ".$error['SQLSTATE']."<br />";
                echo "code: ".$error['code']."<br />";
                echo "message: ".$error['message']."<br />";
            }
        }
    }
} else {
    if( ($errors = sqlsrv_errors() ) != null) {
        foreach( $errors as $error ) {
            echo "SQLSTATE: ".$error['SQLSTATE']."<br />";
            echo "code: ".$error['code']."<br />";
            echo "message: ".$error['message']."<br />";
        }
    }
}

// Cerrar la conexión
sqlsrv_close($conn);
?>

